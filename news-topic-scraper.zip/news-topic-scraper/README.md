# NewsScope — News & Topic Scraper

A lightweight responsive web application for collecting articles from configurable RSS/Atom feeds or HTML article pages, storing them in SQLite, detecting configured topics, and displaying the results in a browser.

## Features
- Responsive web dashboard
- RSS/Atom scraping with feedparser
- Basic HTML scraping with BeautifulSoup
- Configurable topics/keywords
- Search and topic filtering
- Duplicate prevention
- Manual scraping
- Automatic background scraping every 30 minutes
- SQLite storage
- Easy source configuration
- Gunicorn-ready deployment

## Run locally

Python 3.10+:

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

Linux/macOS:
```bash
source .venv/bin/activate
```

Install:
```bash
pip install -r requirements.txt
```

Start:
```bash
python app.py
```

Open `http://127.0.0.1:5000`.

## Add sources

Use the dashboard or edit `sources.json`.

RSS example:
```json
{"name":"Example News","url":"https://example.com/rss.xml","type":"rss","enabled":true}
```

HTML example:
```json
{"name":"Example Web","url":"https://example.com/news","type":"html","enabled":true}
```

RSS/Atom is preferred because its structure is more stable.

## Change topics

Edit them in the dashboard, one per line. Matching is case-insensitive against the title and summary.

## Change automatic interval

In `app.py`, change:
```python
scheduler.add_job(scrape_all,"interval",minutes=30,id="news_scrape",replace_existing=True)
```

## Deploy

On a Linux server:
```bash
pip install -r requirements.txt
gunicorn --bind 0.0.0.0:5000 app:app
```

For a public deployment, put Nginx/Apache or another reverse proxy in front and enable HTTPS.

### Notes
Respect each site's robots.txt, terms of service, copyright rules and rate limits. Some sites require APIs or JavaScript rendering and will not work with the simple HTML scraper.
