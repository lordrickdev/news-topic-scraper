import os, json, sqlite3
from datetime import datetime, timezone
from urllib.parse import urljoin
import feedparser, requests
from bs4 import BeautifulSoup
from apscheduler.schedulers.background import BackgroundScheduler
from flask import Flask, jsonify, render_template, request

BASE_DIR=os.path.dirname(os.path.abspath(__file__))
DB_PATH=os.path.join(BASE_DIR,"news.db")
CONFIG_PATH=os.path.join(BASE_DIR,"sources.json")
app=Flask(__name__)

DEFAULT_TOPICS=["technology","artificial intelligence","business","cybersecurity"]

def load_sources():
    if not os.path.exists(CONFIG_PATH): save_sources([])
    with open(CONFIG_PATH,"r",encoding="utf-8") as f: return json.load(f)

def save_sources(sources):
    with open(CONFIG_PATH,"w",encoding="utf-8") as f: json.dump(sources,f,indent=2)

def get_db():
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

def init_db():
    c=get_db()
    c.execute("""CREATE TABLE IF NOT EXISTS articles(
        id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,url TEXT UNIQUE NOT NULL,
        summary TEXT,source TEXT,published TEXT,scraped_at TEXT NOT NULL,topic TEXT)""")
    c.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
    c.commit(); c.close()

def get_topics():
    c=get_db(); row=c.execute("SELECT value FROM settings WHERE key='topics'").fetchone(); c.close()
    if not row: return DEFAULT_TOPICS
    try: return json.loads(row["value"])
    except Exception: return DEFAULT_TOPICS

def save_topics(topics):
    c=get_db(); c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('topics',?)",(json.dumps(topics),)); c.commit(); c.close()

def clean(v): return BeautifulSoup(v or "","html.parser").get_text(" ",strip=True)

def detect_topic(title,summary,topics):
    text=f"{title} {summary}".lower()
    return next((t for t in topics if t.lower() in text),"General")

def store(article,topics):
    c=get_db()
    try:
        c.execute("""INSERT OR IGNORE INTO articles
        (title,url,summary,source,published,scraped_at,topic) VALUES(?,?,?,?,?,?,?)""",
        (article["title"],article["url"],article["summary"],article["source"],article["published"],
         datetime.now(timezone.utc).isoformat(),detect_topic(article["title"],article["summary"],topics)))
        inserted=c.total_changes; c.commit()
    finally: c.close()
    return inserted

def scrape_rss(source):
    r=requests.get(source["url"],timeout=20,headers={"User-Agent":"NewsScope/1.0"}); r.raise_for_status()
    feed=feedparser.parse(r.content); out=[]
    for e in feed.entries[:50]:
        title=clean(e.get("title","")); link=e.get("link","").strip()
        if title and link:
            out.append({"title":title,"url":link,"summary":clean(e.get("summary",e.get("description","")))[:1000],
                        "source":source["name"],"published":e.get("published",e.get("updated",""))})
    return out

def scrape_html(source):
    r=requests.get(source["url"],timeout=20,headers={"User-Agent":"NewsScope/1.0"}); r.raise_for_status()
    soup=BeautifulSoup(r.text,"html.parser"); out=[]
    for tag in soup.select("article")[:50]:
        a=tag.find("a",href=True); h=tag.find(["h1","h2","h3","h4"])
        if not a or not h: continue
        title=clean(h.get_text(" ",strip=True)); url=urljoin(source["url"],a["href"])
        p=tag.find("p"); summary=clean(p.get_text(" ",strip=True)) if p else ""
        if title and url: out.append({"title":title,"url":url,"summary":summary[:1000],"source":source["name"],"published":""})
    return out

def scrape_all():
    total=0; errors=[]; topics=get_topics()
    for s in [x for x in load_sources() if x.get("enabled",True)]:
        try:
            items=scrape_html(s) if s.get("type","rss").lower()=="html" else scrape_rss(s)
            for item in items: total += store(item,topics)
        except Exception as e: errors.append({"source":s["name"],"error":str(e)})
    return {"inserted":total,"errors":errors}

@app.route("/")
def index(): return render_template("index.html")

@app.get("/api/articles")
def articles():
    q=request.args.get("q","").strip(); topic=request.args.get("topic","").strip()
    limit=min(int(request.args.get("limit",100)),200)
    c=get_db(); sql="SELECT * FROM articles WHERE 1=1"; p=[]
    if q: sql+=" AND (title LIKE ? OR summary LIKE ? OR source LIKE ?)"; x=f"%{q}%"; p += [x,x,x]
    if topic and topic!="All": sql+=" AND topic=?"; p.append(topic)
    sql+=" ORDER BY scraped_at DESC LIMIT ?"; p.append(limit)
    rows=c.execute(sql,p).fetchall(); c.close(); return jsonify([dict(x) for x in rows])

@app.get("/api/topics")
def topics(): return jsonify(get_topics())

@app.post("/api/topics")
def update_topics():
    data=request.get_json(silent=True) or {}; topics=[x.strip() for x in data.get("topics",[]) if x.strip()][:50]
    save_topics(topics); return jsonify({"ok":True,"topics":topics})

@app.get("/api/sources")
def sources(): return jsonify(load_sources())

@app.post("/api/sources")
def add_source():
    d=request.get_json(silent=True) or {}; name=d.get("name","").strip(); url=d.get("url","").strip()
    typ=d.get("type","rss").lower().strip()
    if not name or not url: return jsonify({"error":"Name and URL are required."}),400
    if typ not in ("rss","html"): return jsonify({"error":"Type must be rss or html."}),400
    s=load_sources(); s.append({"name":name,"url":url,"type":typ,"enabled":True}); save_sources(s)
    return jsonify(s),201

@app.delete("/api/sources/<int:index>")
def delete_source(index):
    s=load_sources()
    if index<0 or index>=len(s): return jsonify({"error":"Source not found."}),404
    s.pop(index); save_sources(s); return jsonify(s)

@app.post("/api/scrape")
def scrape(): return jsonify(scrape_all())

@app.get("/api/stats")
def stats():
    c=get_db()
    a=c.execute("SELECT COUNT(*) n FROM articles").fetchone()["n"]
    s=c.execute("SELECT COUNT(DISTINCT source) n FROM articles").fetchone()["n"]
    t=c.execute("SELECT COUNT(DISTINCT topic) n FROM articles").fetchone()["n"]
    c.close(); return jsonify({"articles":a,"sources":s,"topics":t})

init_db()
scheduler=BackgroundScheduler(daemon=True)
scheduler.add_job(scrape_all,"interval",minutes=30,id="news_scrape",replace_existing=True)
scheduler.start()

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
